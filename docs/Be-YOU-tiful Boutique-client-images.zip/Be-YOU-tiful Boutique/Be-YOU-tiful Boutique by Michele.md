# Be-YOU-Tiful Boutique by Michele

---
> NEW CLIENT: WANTS A SHOPIFY WEBSITE built to match this website for her shop
[REFERENCE SITE](https://shopsmithco.com/collections/sale)
- images can be downloaded from facebook or google for her business.

 - THAT WEBSITE IS WHAT SHE WANTS HER NEW WEBSITE TO LOOK LIKE.
 - SHE DOES NOT CURRENTLY HAVE A WEBSITE
---

## GOOGLE BUSINESS PROFILE

> Boutique in Punta Gorda, Florida


Address: 264-A W Marion Ave, Punta Gorda, FL 33950
Phone: (941) 369-1628
Hours:
Wednesday	10AM–5PM
Thursday	10AM–5PM
Friday	10AM–5PM
Saturday	10AM–4PM
Sunday	Closed
Monday
(Labor Day)
Closed
Tuesday	10AM–5PM

>From Be-YOU-Tiful Boutique by Michele
"Unique Boutique with afordable prices...from swimsuits to gowns. size XS to 3X."

---

## SOCIAL MEDIA

[FACEBOOK](https://www.facebook.com/MicheleMonksEnsmingerMansfield)
[PROFILE/LOG0 IMAGE](https://scontent-mia5-1.xx.fbcdn.net/v/t39.30808-1/293435938_437420978382671_5895092750356402939_n.png?stp=dst-png&cstp=mx1280x1280&ctp=s480x480&_nc_cat=104&ccb=1-7&_nc_sid=2d3e12&_nc_ohc=MHLfxbpoI9gQ7kNvwGa28U8&_nc_oc=Adq4phM2Jq386sE2V1kFV9wlt3GaZn0ggFlbUSsjaCNyieuPE7id8UVyZqoz1Wg0lEZqavN9ND46_OGSMjxRGeTc&_nc_zt=24&_nc_ht=scontent-mia5-1.xx&_nc_gid=hGweuiF91rcsbdi364cOWg&_nc_ss=7b289&oh=00_AQJncdpUFdnm8ZikbHl8AdClHUfdffgRNqbF8T_n_YWffQ&oe=6A9DE5E7)

- **FACEBOOK DETAILS**
> Be-YOU-tiful Boutique by Michele
 2.1K followers • 35 following


Intro
264 West Marion Ave, Punta Gorda, Florida.....Accept yourself as you were designed by God

Page · Women's clothing store

264 West Marion Ave. , Punta Gorda, FL, United States, Florida

(941) 369-1628

Beyoutifulboutiquebymichele@gmail.com

Closed now

In-store pickup

100% recommend (16 Reviews)


Categories

Women's clothing store
Contact info

264 West Marion Ave. , Punta Gorda, FL, United States, 33950
Address

Port Charlotte, FL · Fort Myers, FL · North Port, FL · Englewood, FL · Punta Gorda, FL · Cape Coral, FL
Service area

(941) 369-1628
Mobile

beyoutifulboutiquebymichele@gmail.com
Email
Basic info

100% recommend (16 Reviews)

Closed now
Hours

In-store pickup
Services
Reels


---



